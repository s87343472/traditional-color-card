export interface BorderStyle {
  id: string;
  name: string;
  value: string;
  description: string;
}

export const borderStyles: BorderStyle[] = [
  {
    id: 'solid',
    name: '实线',
    value: 'solid',
    description: '传统简约'
  },
  {
    id: 'double',
    name: '双线',
    value: 'double',
    description: '庄重大方'
  },
  {
    id: 'dashed',
    name: '虚线',
    value: 'dashed',
    description: '灵动活泼'
  },
  {
    id: 'dotted',
    name: '点线',
    value: 'dotted',
    description: '清新典雅'
  },
  {
    id: 'groove',
    name: '凹槽',
    value: 'groove',
    description: '立体质感'
  },
  {
    id: 'ridge',
    name: '凸槽',
    value: 'ridge',
    description: '精致雕刻'
  }
];