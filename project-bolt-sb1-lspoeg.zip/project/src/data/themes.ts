import { Color } from '../types';
import { traditionalColors } from './colors';

export interface Theme {
  id: string;
  name: string;
  emotion: string;
  backgroundColor: Color;
  textColor: Color;
  borderColor: Color;
  description: string;
  story: string;
}

// 确保颜色存在
const getColor = (name: string): Color => {
  const color = traditionalColors.find(c => c.name === name);
  if (!color) {
    throw new Error(`Color ${name} not found`);
  }
  return color;
};

export const themes: Theme[] = [
  {
    id: 'elegant',
    name: '雅致',
    emotion: '典雅',
    backgroundColor: getColor('素'),
    textColor: getColor('墨'),
    borderColor: getColor('青矾绿'),
    description: '如同宣纸上的淡墨，传统文人的雅致气质',
    story: '雅致主题汲取传统文人画的精髓，以素雅的色调展现东方美学中的含蓄之美。宣纸般的洁白底色配以淡雅的水墨色调，让每一张卡片都充满文人雅士的风骨。',
  },
  {
    id: 'warm',
    name: '暖阳',
    emotion: '温暖',
    backgroundColor: getColor('琥珀'),
    textColor: getColor('素'),
    borderColor: getColor('檀'),
    description: '犹如午后的阳光，温暖而不失优雅',
    story: '暖阳主题灵感来自冬日午后的阳光，温暖而不炙热。琥珀色的背景让人联想起古老的茶室，在那里时光仿佛静止，只余下一片温暖祥和。',
  },
  {
    id: 'passion',
    name: '热烈',
    emotion: '热情',
    backgroundColor: getColor('赤'),
    textColor: getColor('素'),
    borderColor: getColor('海棠红'),
    description: '似火般热烈，展现东方的热情与活力',
    story: '热烈主题采用中国传统喜庆色彩，赤红如火，象征着东方特有的热情奔放。这是一个充满生命力与欢愉的主题，适合表达热烈的情感。',
  },
  {
    id: 'spring',
    name: '春晓',
    emotion: '生机',
    backgroundColor: getColor('露花红'),
    textColor: getColor('松绿'),
    borderColor: getColor('四青'),
    description: '春日晨曦，万物复苏的生机盎然',
    story: '春晓主题取意于朝露初晴，露花红的背景如同春日里初绽的花瓣，搭配松绿色的文字，展现了春天特有的生机与希望。这是一个充满新生力量的主题。',
  },
  {
    id: 'summer',
    name: '夏荷',
    emotion: '清凉',
    backgroundColor: getColor('天青'),
    textColor: getColor('墨'),
    borderColor: getColor('青金'),
    description: '荷塘月色，清凉雅致的夏日意境',
    story: '夏荷主题灵感源自传统山水画中的荷塘月色，天青色的背景犹如清澈的水面，搭配墨色的文字，营造出一派清凉雅致的夏日氛围。',
  },
  {
    id: 'autumn',
    name: '秋韵',
    emotion: '沉稳',
    backgroundColor: getColor('琥珀'),
    textColor: getColor('青矾绿'),
    borderColor: getColor('檀'),
    description: '金秋时节，沉稳内敛的成熟气质',
    story: '秋韵主题以金秋时节的色彩为灵感，琥珀色的背景如同成熟的稻穗，搭配青矾绿的文字，展现了秋天特有的沉稳与丰收的喜悦。',
  },
  {
    id: 'winter',
    name: '冬雪',
    emotion: '素净',
    backgroundColor: getColor('素'),
    textColor: getColor('靛蓝'),
    borderColor: getColor('青金'),
    description: '瑞雪纷飞，素净淡雅的冬日意境',
    story: '冬雪主题以皑皑白雪为意象，素白的背景配以靛蓝色的文字，如同冬日里的一抹寒梅，清冷而不失风骨，展现了冬天的纯净与坚毅。',
  },
  {
    id: 'ink',
    name: '墨韵',
    emotion: '深沉',
    backgroundColor: getColor('墨'),
    textColor: getColor('素'),
    borderColor: getColor('青金'),
    description: '水墨丹青，蕴含东方的深邃智慧',
    story: '墨韵主题取意于传统水墨画，以浓墨重彩为基调，展现出东方哲学的深邃智慧。墨色的背景如同浩瀚的宇宙，让每一个字都承载着深远的意境。',
  },
  {
    id: 'lotus',
    name: '荷韵',
    emotion: '清雅',
    backgroundColor: getColor('露花红'),
    textColor: getColor('墨'),
    borderColor: getColor('四青'),
    description: '出淤泥而不染，濯清涟而不妖',
    story: '荷韵主题灵感来自传统诗词中的荷花意象，露花红的背景似荷瓣般娇嫩，搭配墨色文字，展现了荷花"出淤泥而不染"的高洁品格。',
  },
  {
    id: 'bamboo',
    name: '竹影',
    emotion: '高雅',
    backgroundColor: getColor('四青'),
    textColor: getColor('素'),
    borderColor: getColor('松绿'),
    description: '竹影摇曳，展现君子的品格风骨',
    story: '竹影主题以竹林深处的光影为灵感，四青色的背景如同竹林的氤氲，搭配素白的文字，展现了竹子虚心有节的君子品格。',
  },
  {
    id: 'plum',
    name: '梅韵',
    emotion: '傲雪',
    backgroundColor: getColor('素'),
    textColor: getColor('海棠红'),
    borderColor: getColor('露花红'),
    description: '傲雪凌霜，展现坚韧的精神品质',
    story: '梅韵主题取意于傲雪凌霜的寒梅，素白的背景如同白雪，搭配海棠红的文字，展现了梅花不畏严寒、傲然绽放的坚韧品格。',
  },
  {
    id: 'pine',
    name: '松风',
    emotion: '挺拔',
    backgroundColor: getColor('松绿'),
    textColor: getColor('素'),
    borderColor: getColor('青矾绿'),
    description: '青松挺拔，展现坚贞不渝的品格',
    story: '松风主题以苍松翠柏为意象，松绿色的背景似松林般深邃，搭配素白的文字，展现了松树四季常青、坚贞不渝的品格特质。',
  }
];