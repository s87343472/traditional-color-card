import { Color } from '../types';

export const traditionalColors: Color[] = [
  // 基础色
  { name: '素', pinyin: 'sù', hex: '#FFFFFF', emotion: '纯净', story: '素色象征纯洁与本真，在传统美学中代表返璞归真的境界。' },
  { name: '墨', pinyin: 'mò', hex: '#000000', emotion: '深沉', story: '墨色来源于传统水墨画，象征着深邃与永恒。' },
  
  // 红色系
  { name: '檀', pinyin: 'tán', hex: '#B36D61', emotion: '温暖', story: '檀色源自檀木，在古代是重要的香料和建材，象征着温暖与贵重。' },
  { name: '琥珀', pinyin: 'hǔ pò', hex: '#CA6924', emotion: '温馨', story: '琥珀是松脂经过百万年演化而成的宝石，古人用它来形容温暖的色调。' },
  { name: '赤', pinyin: 'chì', hex: '#C3272B', emotion: '热烈', story: '赤色在五行中属火，象征着热情与生机，是最纯正的红色。' },
  { name: '玫瑰紫', pinyin: 'méi guī zǐ', hex: '#BA2F7B', emotion: '浪漫', story: '玫瑰紫色彩艳丽，在古代多用于女子的衣裳和妆饰，象征着浪漫与优雅。' },
  { name: '海棠红', pinyin: 'hǎi táng hóng', hex: '#DB5A6B', emotion: '艳丽', story: '海棠是中国传统园林常见的花卉，其红色明艳动人，常被用来形容美人的容颜。' },
  { name: '露花红', pinyin: 'lù huā hóng', hex: '#E77C8E', emotion: '清丽', story: '露花红如同沾染了晨露的花瓣，显得格外清丽脱俗。' },
  
  // 绿色系
  { name: '青矾绿', pinyin: 'qīng fán lǜ', hex: '#2C9678', emotion: '沉稳', story: '青矾是古代的一种矿物，其色青翠雅致，多用于文人画的设色。' },
  { name: '四青', pinyin: 'sì qīng', hex: '#1E9D7C', emotion: '典雅', story: '四青是传统青绿山水画中常用的颜色之一，象征着文人的高雅情操。' },
  { name: '松绿', pinyin: 'sōng lǜ', hex: '#057748', emotion: '深沉', story: '松绿取自青松之色，象征着坚韧不拔的品格。' },
  
  // 蓝色系
  { name: '天青', pinyin: 'tiān qīng', hex: '#2BAAE2', emotion: '清澈', story: '天青色源自宋代汝窑瓷器的釉色，被誉为"雨过天青云破处"。' },
  { name: '青金', pinyin: 'qīng jīn', hex: '#1772B4', emotion: '高贵', story: '青金色在古代多用于描绘宫廷器物，象征着尊贵与权威。' },
  { name: '靛蓝', pinyin: 'diàn lán', hex: '#065279', emotion: '深邃', story: '靛蓝源自蓼蓝等植物提取的染料，是传统织染工艺中重要的颜色。' },
];