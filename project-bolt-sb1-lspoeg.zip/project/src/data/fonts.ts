export interface Font {
  name: string;
  family: string;
  style: string;
  description: string;
  languages?: string[]; // 支持的语言
}

export const fonts: Font[] = [
  // 中文字体
  {
    name: '宋体',
    family: '"Noto Serif SC", serif',
    style: 'serif',
    description: '端庄典雅，结构严谨',
    languages: ['zh-CN']
  },
  {
    name: '楷体',
    family: '"KaiTi", "楷体"',
    style: 'normal',
    description: '工整清秀，笔画分明',
    languages: ['zh-CN']
  },
  {
    name: '仿宋',
    family: '"FangSong", "仿宋"',
    style: 'normal',
    description: '庄重大方，结构严谨',
    languages: ['zh-CN']
  },
  {
    name: '黑体',
    family: '"Noto Sans SC", sans-serif',
    style: 'sans-serif',
    description: '现代简约，清晰易读',
    languages: ['zh-CN']
  },
  
  // 英文字体
  {
    name: 'Serif',
    family: '"Playfair Display", serif',
    style: 'serif',
    description: 'Classic and elegant',
    languages: ['en-US']
  },
  {
    name: 'Sans',
    family: '"Inter", sans-serif',
    style: 'sans-serif',
    description: 'Modern and clean',
    languages: ['en-US']
  },
  
  // 日文字体
  {
    name: '明朝体',
    family: '"Noto Serif JP", serif',
    style: 'serif',
    description: '伝統的で格調高い',
    languages: ['ja-JP']
  },
  {
    name: 'ゴシック',
    family: '"Noto Sans JP", sans-serif',
    style: 'sans-serif',
    description: 'モダンで読みやすい',
    languages: ['ja-JP']
  }
];