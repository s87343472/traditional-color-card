import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { CardEditor } from './components/CardEditor';
import { ControlPanel } from './components/ControlPanel';
import { themes } from './data/themes';
import { fonts } from './data/fonts';
import { borderStyles } from './data/borderStyles';
import { useTranslation } from 'react-i18next';

export default function App() {
  const { t } = useTranslation();
  const [selectedTheme, setSelectedTheme] = useState(themes[0]);
  const [fontSize, setFontSize] = useState(32);
  const [borderWidth, setBorderWidth] = useState(2);
  const [selectedFont, setSelectedFont] = useState(fonts[0]);
  const [selectedBorderStyle, setSelectedBorderStyle] = useState(borderStyles[0]);
  const [showControls, setShowControls] = useState(false);

  // 根据选中的主题生成默认文字
  const getDefaultText = (theme: typeof themes[0]) => {
    return t(`themes.${theme.id}.story`);
  };

  const [text, setText] = useState(getDefaultText(selectedTheme));

  // 更新主题时同步更新文字
  const handleThemeSelect = (theme: typeof themes[0]) => {
    setSelectedTheme(theme);
    setText(getDefaultText(theme));
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-stone-50 to-stone-100">
        <main className="container mx-auto px-4 py-6">
          {/* Header */}
          <div className="text-center mb-6">
            <h1 className="text-2xl font-serif text-stone-800">{t('appName')}</h1>
            <p className="text-sm text-stone-500 mt-1">{t('appDesc')}</p>
          </div>

          {/* Card Editor */}
          <div className="max-w-sm mx-auto">
            <CardEditor
              text={text}
              onTextChange={setText}
              backgroundColor={selectedTheme.backgroundColor}
              textColor={selectedTheme.textColor}
              borderColor={selectedTheme.borderColor}
              fontSize={fontSize}
              borderWidth={borderWidth}
              font={selectedFont}
              borderStyle={selectedBorderStyle}
              onOpenControls={() => setShowControls(true)}
            />
          </div>

          {/* Control Panel */}
          <ControlPanel
            isOpen={showControls}
            onClose={() => setShowControls(false)}
            themes={themes}
            selectedTheme={selectedTheme}
            onThemeSelect={handleThemeSelect}
            fontSize={fontSize}
            onFontSizeChange={setFontSize}
            borderWidth={borderWidth}
            onBorderWidthChange={setBorderWidth}
            selectedFont={selectedFont}
            onFontChange={setSelectedFont}
            selectedBorderStyle={selectedBorderStyle}
            onBorderStyleChange={setSelectedBorderStyle}
          />
        </main>
      </div>
    </Layout>
  );
}