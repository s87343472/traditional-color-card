export const zhCN = {
  translation: {
    appName: '传统色彩卡片生成器',
    appDesc: '探索传统色彩之美',
    
    // 操作按钮
    download: '下载',
    copy: '复制',
    preview: '预览',
    settings: '设置',
    close: '关闭',
    
    // 主题相关
    themeSelection: '主题选择',
    styleSettings: '样式设置',
    fontStyle: '字体样式',
    fontSize: '字体大小',
    borderStyle: '边框样式',
    borderWidth: '边框粗细',
    cardSettings: '卡片设置',
    
    // 主题
    themes: {
      elegant: {
        name: '雅致',
        emotion: '典雅',
        description: '如同宣纸上的淡墨，传统文人的雅致气质',
        story: '雅致主题汲取传统文人画的精髓，以素雅的色调展现东方美学中的含蓄之美。宣纸般的洁白底色配以淡雅的水墨色调，让每一张卡片都充满文人雅士的风骨。'
      },
      warm: {
        name: '暖阳',
        emotion: '温暖',
        description: '犹如午后的阳光，温暖而不失优雅',
        story: '暖阳主题灵感来自冬日午后的阳光，温暖而不炙热。琥珀色的背景让人联想起古老的茶室，在那里时光仿佛静止，只余下一片温暖祥和。'
      },
      passion: {
        name: '热烈',
        emotion: '热情',
        description: '似火般热烈，展现东方的热情与活力',
        story: '热烈主题采用中国传统喜庆色彩，赤红如火，象征着东方特有的热情奔放。这是一个充满生命力与欢愉的主题，适合表达热烈的情感。'
      },
      tranquil: {
        name: '静谧',
        emotion: '宁静',
        description: '如同平静的湖面，沉淀出内心的宁静',
        story: '静谧主题仿佛一泓秋水，天青色的背景让人想起宋代汝窑瓷器的釉色。在这里，繁杂的思绪归于平静，只余下内心最本真的声音。'
      },
      natural: {
        name: '自然',
        emotion: '生机',
        description: '青翠欲滴，展现自然的勃勃生机',
        story: '自然主题取意于山林竹海，四青的色调让人联想起雨后新竹的清新。这是一个充满生机与活力的主题，仿佛能闻到竹林间的清新空气。'
      },
      romantic: {
        name: '浪漫',
        emotion: '柔美',
        description: '似花般绚丽，流露东方的浪漫情怀',
        story: '浪漫主题灵感来自于晨露中的海棠花，粉红的色调温柔而不失韵味。这是一个充满诗意的主题，适合表达温柔的情感与美好的祝愿。'
      },
      mysterious: {
        name: '玄妙',
        emotion: '深邃',
        description: '深邃如墨，蕴含东方的神秘智慧',
        story: '玄妙主题采用浓墨重彩，象征着东方哲学中的深邃智慧。墨色的背景如同浩瀚的宇宙，让每一个字都承载着深远的意境。'
      },
      fresh: {
        name: '清新',
        emotion: '活力',
        description: '清新脱俗，展现年轻的活力气息',
        story: '清新主题如同春日的第一抹新绿，清新而富有朝气。这是一个充满青春活力的主题，适合表达积极向上的心情。'
      },
      classic: {
        name: '经典',
        emotion: '庄重',
        description: '庄重典雅，传承传统文化的精髓',
        story: '经典主题传承了中国传统书画的形式美，以素白为底，墨色为界，体现出一种庄重而不失灵动的气质。这是最能体现东方美学的主题之一。'
      }
    },

    // 字体样式
    fonts: {
      songti: {
        name: '宋体',
        description: '端庄典雅，结构严谨'
      },
      kaiti: {
        name: '楷体',
        description: '工整清秀，笔画分明'
      },
      fangsong: {
        name: '仿宋',
        description: '庄重大方，结构严谨'
      },
      heiti: {
        name: '黑体',
        description: '现代简约，清晰易读'
      }
    },

    // 边框样式
    borderStyles: {
      solid: {
        name: '实线',
        description: '传统简约'
      },
      double: {
        name: '双线',
        description: '庄重大方'
      },
      dashed: {
        name: '虚线',
        description: '灵动活泼'
      },
      dotted: {
        name: '点线',
        description: '清新典雅'
      },
      groove: {
        name: '凹槽',
        description: '立体质感'
      },
      ridge: {
        name: '凸槽',
        description: '精致雕刻'
      }
    },

    // 提示文本
    inputPlaceholder: '在此输入文字...',
    characterCount: '{{current}}/{{max}}字',
    searchPlaceholder: '搜索颜色名称、拼音或情感...',
    random: '随机',
    
    // 复制提示
    copySuccess: '已复制到剪贴板',
    copyFailed: '复制失败，请手动下载',
    
    // 预览
    themePreview: '主题预览',
    page: '第{{current}}页/共{{total}}页',
    
    // 其他
    loading: '加载中...',
    error: '出错了',
    retry: '重试',
    confirm: '确定',
    cancel: '取消'
  }
};