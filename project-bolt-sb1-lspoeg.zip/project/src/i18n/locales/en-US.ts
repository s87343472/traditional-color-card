export const enUS = {
  translation: {
    appName: 'Traditional Color Card Generator',
    appDesc: 'Explore the Beauty of Traditional Colors',
    
    // Actions
    download: 'Download',
    copy: 'Copy',
    preview: 'Preview',
    settings: 'Settings',
    close: 'Close',
    
    // Theme Related
    themeSelection: 'Theme Selection',
    styleSettings: 'Style Settings',
    fontStyle: 'Font Style',
    fontSize: 'Font Size',
    borderStyle: 'Border Style',
    borderWidth: 'Border Width',
    cardSettings: 'Card Settings',
    
    // Themes
    themes: {
      elegant: {
        name: 'Elegant',
        emotion: 'Classic',
        description: 'Like ink on rice paper, embodying the elegant spirit',
        story: 'The elegant theme draws inspiration from traditional literati paintings, using subdued tones to express subtle beauty. The white background, reminiscent of rice paper, paired with ink-like accents, creates a scholarly atmosphere.'
      },
      warm: {
        name: 'Warm',
        emotion: 'Cozy',
        description: 'Like afternoon sunlight, warm and graceful',
        story: 'The warm theme is inspired by winter afternoon sunlight, warm but not harsh. The amber background evokes ancient tea rooms, where time seems to stand still in a cozy atmosphere.'
      },
      passion: {
        name: 'Passionate',
        emotion: 'Energetic',
        description: 'Vibrant like fire, showing Oriental passion',
        story: 'The passionate theme uses traditional celebratory colors, red as fire, symbolizing the unique enthusiasm of the East. This is a theme full of vitality and joy.'
      },
      tranquil: {
        name: 'Tranquil',
        emotion: 'Peaceful',
        description: 'Like a calm lake surface, reflecting inner peace',
        story: 'The tranquil theme is like autumn waters, with a celadon background reminiscent of Song Dynasty porcelain glazes. Here, complex thoughts settle into peaceful clarity.'
      },
      natural: {
        name: 'Natural',
        emotion: 'Vital',
        description: 'Fresh and verdant, showing natural vitality',
        story: 'The natural theme draws from mountain forests and bamboo groves. The green tones evoke fresh bamboo after rain, creating a sense of natural vitality.'
      },
      romantic: {
        name: 'Romantic',
        emotion: 'Gentle',
        description: 'Delicate as flowers, expressing Oriental romance',
        story: 'The romantic theme is inspired by morning dew on begonia flowers, with pink tones that are gentle yet sophisticated. This is a poetic theme suitable for expressing tender emotions.'
      },
      mysterious: {
        name: 'Mysterious',
        emotion: 'Deep',
        description: 'Deep as ink, containing Oriental wisdom',
        story: 'The mysterious theme uses deep ink colors, symbolizing the profound wisdom of Eastern philosophy. The dark background is like the vast universe, giving each character deep meaning.'
      },
      fresh: {
        name: 'Fresh',
        emotion: 'Youthful',
        description: 'Pure and refreshing, showing youthful spirit',
        story: 'The fresh theme is like the first touch of spring green, refreshing and energetic. This is a theme full of youthful vigor, perfect for expressing positive emotions.'
      },
      classic: {
        name: 'Classic',
        emotion: 'Dignified',
        description: 'Dignified and elegant, inheriting tradition',
        story: 'The classic theme inherits the aesthetic form of traditional Chinese painting and calligraphy, using white background and ink borders to create a dignified yet dynamic character.'
      }
    },

    // Font Styles
    fonts: {
      serif: {
        name: 'Serif',
        description: 'Classic and elegant'
      },
      sans: {
        name: 'Sans',
        description: 'Modern and clean'
      }
    },

    // Border Styles
    borderStyles: {
      solid: {
        name: 'Solid',
        description: 'Traditional and simple'
      },
      double: {
        name: 'Double',
        description: 'Dignified and proper'
      },
      dashed: {
        name: 'Dashed',
        description: 'Lively and dynamic'
      },
      dotted: {
        name: 'Dotted',
        description: 'Fresh and elegant'
      },
      groove: {
        name: 'Groove',
        description: '3D texture'
      },
      ridge: {
        name: 'Ridge',
        description: 'Delicate carving'
      }
    },

    // Prompts
    inputPlaceholder: 'Enter text here...',
    characterCount: '{{current}}/{{max}} chars',
    searchPlaceholder: 'Search by name, pinyin, or emotion...',
    random: 'Random',
    
    // Copy Messages
    copySuccess: 'Copied to clipboard',
    copyFailed: 'Copy failed, please download manually',
    
    // Preview
    themePreview: 'Theme Preview',
    page: 'Page {{current}} of {{total}}',
    
    // Others
    loading: 'Loading...',
    error: 'Error occurred',
    retry: 'Retry',
    confirm: 'Confirm',
    cancel: 'Cancel'
  }
};