export const jaJP = {
  translation: {
    appName: '伝統色カードジェネレーター',
    appDesc: '伝統色の美を探求する',
    
    // アクション
    download: 'ダウンロード',
    copy: 'コピー',
    preview: 'プレビュー',
    settings: '設定',
    close: '閉じる',
    
    // テーマ関連
    themeSelection: 'テーマ選択',
    styleSettings: 'スタイル設定',
    fontStyle: 'フォントスタイル',
    fontSize: 'フォントサイズ',
    borderStyle: '枠線スタイル',
    borderWidth: '枠線の太さ',
    cardSettings: 'カード設定',
    
    // テーマ
    themes: {
      elegant: {
        name: '雅',
        emotion: '優雅',
        description: '墨絵のような優美さを表現',
        story: '雅テーマは伝統的な水墨画からインスピレーションを得て、控えめな色調で繊細な美しさを表現します。和紙を思わせる白い背景に、墨のようなアクセントが、文人の雰囲気を醸し出します。'
      },
      warm: {
        name: '温',
        emotion: '温かい',
        description: '午後の陽光のような温かさ',
        story: '温テーマは冬の午後の陽光からインスピレーションを得ています。琥珀色の背景は、古い茶室を思わせ、時が止まったような温かな雰囲気を作り出します。'
      },
      passion: {
        name: '情熱',
        emotion: '活力',
        description: '炎のような情熱を表現',
        story: '情熱テーマは伝統的な祝祭色を用い、火のような赤で東洋特有の熱意を象徴します。活力と喜びに満ちたテーマです。'
      },
      tranquil: {
        name: '静寂',
        emotion: '平穏',
        description: '静かな湖面のような心の平安',
        story: '静寂テーマは秋の水面のよう。青磁色の背景は宋代の陶磁器の釉薬を思わせます。複雑な思いが静けさの中で整理される場所です。'
      },
      natural: {
        name: '自然',
        emotion: '生命力',
        description: '自然の生命力を表現',
        story: '自然テーマは山林や竹林からインスピレーションを得ています。緑の色調は雨上がりの新鮮な竹を思わせ、自然の生命力を感じさせます。'
      },
      romantic: {
        name: '浪漫',
        emotion: '優しさ',
        description: '花のような繊細な東洋の浪漫',
        story: '浪漫テーマは朝露に濡れた海棠の花からインスピレーションを得ています。優しくも品のあるピンク色調で、詩情豊かな感情表現に適しています。'
      },
      mysterious: {
        name: '神秘',
        emotion: '深遠',
        description: '東洋の知恵を秘めた深み',
        story: '神秘テーマは深い墨色を用いて、東洋哲学の深遠な知恵を象徴します。墨色の背景は広大な宇宙のように、各文字に深い意味を与えます。'
      },
      fresh: {
        name: '清新',
        emotion: '若々しさ',
        description: '若々しい精神を表現',
        story: '清新テーマは春の最初の新緑のよう。清々しく活力に満ちています。若々しい活力に満ちたテーマで、前向きな気持ちの表現に最適です。'
      },
      classic: {
        name: '古典',
        emotion: '品格',
        description: '伝統を継承する品格',
        story: '古典テーマは中国の伝統的な書画の美的形式を継承し、白地に墨の境界線を用いて、厳かでありながら活気のある雰囲気を醸し出します。'
      }
    },

    // フォントスタイル
    fonts: {
      mincho: {
        name: '明朝体',
        description: '伝統的で格調高い'
      },
      gothic: {
        name: 'ゴシック',
        description: 'モダンで読みやすい'
      }
    },

    // 枠線スタイル
    borderStyles: {
      solid: {
        name: '実線',
        description: '伝統的でシンプル'
      },
      double: {
        name: '二重線',
        description: '厳かで正統的'
      },
      dashed: {
        name: '破線',
        description: '軽やかで活発'
      },
      dotted: {
        name: '点線',
        description: '清楚で優美'
      },
      groove: {
        name: '溝線',
        description: '立体的な質感'
      },
      ridge: {
        name: '浮線',
        description: '繊細な彫刻'
      }
    },

    // プロンプト
    inputPlaceholder: 'ここにテキストを入力...',
    characterCount: '{{current}}/{{max}}文字',
    searchPlaceholder: '色名、読み方、感情で検索...',
    random: 'ランダム',
    
    // コピーメッセージ
    copySuccess: 'クリップボードにコピーしました',
    copyFailed: 'コピーに失敗しました。手動でダウンロードしてください',
    
    // プレビュー
    themePreview: 'テーマプレビュー',
    page: 'ページ{{current}}/{{total}}',
    
    // その他
    loading: '読み込み中...',
    error: 'エラーが発生しました',
    retry: '再試行',
    confirm: '確認',
    cancel: 'キャンセル'
  }
};