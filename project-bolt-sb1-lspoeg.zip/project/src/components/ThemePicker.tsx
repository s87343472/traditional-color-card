import React from 'react';
import { Theme } from '../data/themes';
import { Info } from 'lucide-react';
import { getSuitableContrastColor } from '../utils/colors';

interface ThemePickerProps {
  themes: Theme[];
  selectedTheme: Theme;
  onThemeSelect: (theme: Theme) => void;
}

export function ThemePicker({
  themes,
  selectedTheme,
  onThemeSelect,
}: ThemePickerProps) {
  return (
    <div className="grid grid-cols-3 gap-4">
      {themes.map((theme) => (
        <div key={theme.id} className="relative group">
          <button
            onClick={() => onThemeSelect(theme)}
            className={`relative w-full aspect-square rounded-xl overflow-hidden transition-all duration-300 ${
              selectedTheme.id === theme.id 
                ? 'ring-2 ring-stone-800 ring-offset-2 scale-105'
                : 'hover:scale-105'
            }`}
            style={{
              backgroundColor: theme.backgroundColor.hex,
              border: `2px ${theme.borderColor.hex} solid`,
            }}
          >
            {/* Theme Preview */}
            <div className="absolute inset-0 p-3 flex flex-col">
              {/* Theme Title */}
              <div 
                className="text-sm font-medium mb-1"
                style={{
                  color: getSuitableContrastColor(
                    theme.backgroundColor.hex,
                    theme.textColor.hex
                  ),
                }}
              >
                {theme.name}
              </div>
              
              {/* Theme Emotion Tag */}
              <div 
                className="text-xs px-2 py-1 rounded-full w-fit"
                style={{
                  backgroundColor: `${theme.borderColor.hex}20`,
                  color: getSuitableContrastColor(
                    theme.backgroundColor.hex,
                    theme.textColor.hex
                  ),
                }}
              >
                {theme.emotion}
              </div>

              {/* Theme Preview Text */}
              <div 
                className="mt-auto text-xs opacity-80 line-clamp-2"
                style={{
                  color: getSuitableContrastColor(
                    theme.backgroundColor.hex,
                    theme.textColor.hex
                  ),
                }}
              >
                {theme.description}
              </div>
            </div>

            {/* Hover Effect */}
            <div 
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              style={{
                background: `linear-gradient(to bottom, transparent, ${theme.backgroundColor.hex}CC)`,
              }}
            />
          </button>

          {/* Theme Info Tooltip */}
          <div className="absolute top-2 right-2 z-10">
            <div className="relative group/tooltip">
              <button
                className="p-1.5 rounded-full bg-white/80 hover:bg-white transition-colors shadow-sm"
                onClick={(e) => e.stopPropagation()}
              >
                <Info className="w-3 h-3 text-stone-600" />
              </button>
              <div className="absolute bottom-full right-0 mb-2 w-48 invisible group-hover/tooltip:visible opacity-0 group-hover/tooltip:opacity-100 transition-all transform scale-95 group-hover/tooltip:scale-100">
                <div className="relative bg-white rounded-lg shadow-lg p-3 text-xs">
                  <div className="font-medium mb-1">{theme.name}</div>
                  <div className="text-stone-600">{theme.description}</div>
                  <div className="absolute -bottom-1 right-3 w-2 h-2 bg-white transform rotate-45" />
                </div>
              </div>
            </div>
          </div>

          {/* Selection Indicator */}
          {selectedTheme.id === theme.id && (
            <div 
              className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-4 rounded-full"
              style={{ backgroundColor: theme.borderColor.hex }}
            />
          )}
        </div>
      ))}
    </div>
  );
}