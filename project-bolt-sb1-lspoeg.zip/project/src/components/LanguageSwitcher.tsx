import React from 'react';
import { useTranslation } from 'react-i18next';
import { Languages } from 'lucide-react';

const languages = [
  { code: 'zh-CN', name: '简体中文' },
  { code: 'en-US', name: 'English' },
  { code: 'ja-JP', name: '日本語' },
];

export function LanguageSwitcher() {
  const { i18n } = useTranslation();

  return (
    <div className="relative group">
      <button className="p-2 hover:bg-stone-100 rounded-lg transition-colors flex items-center gap-2">
        <Languages className="w-5 h-5" />
        <span className="text-sm hidden sm:inline">
          {languages.find(lang => lang.code === i18n.language)?.name || '简体中文'}
        </span>
      </button>
      
      <div className="absolute right-0 top-full mt-2 w-32 bg-white rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all transform origin-top-right scale-95 group-hover:scale-100">
        {languages.map(lang => (
          <button
            key={lang.code}
            onClick={() => i18n.changeLanguage(lang.code)}
            className={`w-full px-4 py-2 text-left text-sm hover:bg-stone-50 first:rounded-t-lg last:rounded-b-lg ${
              i18n.language === lang.code ? 'text-stone-900 font-medium' : 'text-stone-600'
            }`}
          >
            {lang.name}
          </button>
        ))}
      </div>
    </div>
  );
}