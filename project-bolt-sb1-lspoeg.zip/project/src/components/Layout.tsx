import React from 'react';
import { Github } from 'lucide-react';
import { LanguageSwitcher } from './LanguageSwitcher';
import { useTranslation } from 'react-i18next';

export function Layout({ children }: { children: React.ReactNode }) {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white shadow-sm">
        <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-lg font-medium text-stone-800">{t('appName')}</div>
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-stone-600 hover:text-stone-900 transition-colors"
            >
              <Github className="w-5 h-5" />
            </a>
          </div>
        </nav>
      </header>

      {children}

      <footer className="mt-auto bg-white border-t border-stone-200">
        <div className="container mx-auto px-4 py-6 text-center text-stone-600">
          <p>{t('appDesc')}</p>
        </div>
      </footer>
    </div>
  );
}