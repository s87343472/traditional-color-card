import React, { useRef, useEffect, useState } from 'react';
import { Download, Copy, Eye, Settings } from 'lucide-react';
import html2canvas from 'html2canvas';
import { getSuitableContrastColor } from '../utils/colors';
import { ThemePreview } from './ThemePreview';

interface CardEditorProps {
  text: string;
  onTextChange: (text: string) => void;
  backgroundColor: { hex: string };
  textColor: { hex: string };
  borderColor: { hex: string };
  fontSize: number;
  borderWidth: number;
  font: { family: string };
  borderStyle: { value: string };
  onOpenControls: () => void;
}

const MAX_CHARS = 200;
const MIN_CARD_HEIGHT = 240;
const MAX_CARD_HEIGHT = 700;
const PADDING = 40;
const LINE_HEIGHT = 2;

export function CardEditor({
  text,
  onTextChange,
  backgroundColor,
  textColor,
  borderColor,
  fontSize,
  borderWidth,
  font,
  borderStyle,
  onOpenControls,
}: CardEditorProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [cardHeight, setCardHeight] = useState(MIN_CARD_HEIGHT);
  const [showPreview, setShowPreview] = useState(false);

  // 处理文本输入，限制字数
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value.slice(0, MAX_CHARS);
    onTextChange(newText);
  };

  // 自动调整文本区域高度
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      const newHeight = Math.max(
        Math.min(scrollHeight + PADDING * 2, MAX_CARD_HEIGHT),
        MIN_CARD_HEIGHT
      );
      setCardHeight(newHeight);
      textareaRef.current.style.height = `${newHeight - PADDING * 2}px`;
    }
  }, [text, fontSize]);

  // 生成图片
  const generateImage = async () => {
    if (!cardRef.current) return null;

    // 创建临时容器
    const tempContainer = document.createElement('div');
    tempContainer.style.position = 'absolute';
    tempContainer.style.left = '-9999px';
    tempContainer.style.top = '-9999px';
    document.body.appendChild(tempContainer);

    // 克隆卡片元素
    const clone = cardRef.current.cloneNode(true) as HTMLElement;
    clone.style.width = `${cardRef.current.offsetWidth}px`;
    clone.style.height = `${cardHeight}px`;
    
    // 替换 textarea 为 div
    const textarea = clone.querySelector('textarea');
    if (textarea) {
      const div = document.createElement('div');
      div.style.position = 'absolute';
      div.style.inset = '0';
      div.style.margin = 'auto';
      div.style.padding = `${PADDING}px`;
      div.style.width = '100%';
      div.style.height = '100%';
      div.style.color = getSuitableContrastColor(backgroundColor.hex, textColor.hex);
      div.style.fontSize = `${fontSize}px`;
      div.style.fontFamily = font.family;
      div.style.lineHeight = `${LINE_HEIGHT}`;
      div.style.whiteSpace = 'pre-wrap';
      div.style.overflowWrap = 'break-word';
      div.style.wordBreak = 'break-word';
      div.style.textAlign = 'left';
      div.textContent = text;
      textarea.parentNode?.replaceChild(div, textarea);
    }

    // 移除设置按钮和字数统计
    const settingsBtn = clone.querySelector('button');
    if (settingsBtn) settingsBtn.remove();
    const charCount = clone.querySelector('[class*="absolute bottom-2"]');
    if (charCount) charCount.remove();

    tempContainer.appendChild(clone);

    try {
      const canvas = await html2canvas(clone, {
        scale: 2,
        useCORS: true,
        backgroundColor: null,
        logging: false,
      });

      tempContainer.remove();
      return canvas;
    } catch (err) {
      console.error('Failed to generate image:', err);
      tempContainer.remove();
      return null;
    }
  };

  // 复制图片到剪贴板
  const handleCopy = async () => {
    const canvas = await generateImage();
    if (!canvas) return;
    
    try {
      canvas.toBlob(async (blob) => {
        if (blob) {
          try {
            const data = new ClipboardItem({ 'image/png': blob });
            await navigator.clipboard.write([data]);
            alert('已复制到剪贴板');
          } catch (err) {
            console.error('Failed to copy to clipboard:', err);
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = '传统色彩卡片.png';
            link.click();
            URL.revokeObjectURL(url);
          }
        }
      }, 'image/png', 1.0);
    } catch (err) {
      console.error('Failed to create image:', err);
    }
  };

  // 下载图片
  const handleDownload = async () => {
    const canvas = await generateImage();
    if (!canvas) return;
    
    try {
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = '传统色彩卡片.png';
          link.click();
          URL.revokeObjectURL(url);
        }
      }, 'image/png', 1.0);
    } catch (err) {
      console.error('Failed to download image:', err);
    }
  };

  return (
    <div className="space-y-4">
      <div
        ref={cardRef}
        className="w-full rounded-2xl shadow-sm relative transition-all duration-300 ease-in-out"
        style={{
          backgroundColor: backgroundColor.hex,
          border: `${borderWidth}px ${borderStyle.value} ${borderColor.hex}`,
          height: `${cardHeight}px`,
        }}
      >
        <textarea
          ref={textareaRef}
          value={text}
          onChange={handleTextChange}
          maxLength={MAX_CHARS}
          className="absolute inset-0 p-10 w-full h-full bg-transparent border-none outline-none resize-none"
          style={{
            color: getSuitableContrastColor(backgroundColor.hex, textColor.hex),
            fontSize: `${fontSize}px`,
            fontFamily: font.family,
            lineHeight: `${LINE_HEIGHT}`,
            whiteSpace: 'pre-wrap',
            overflowWrap: 'break-word',
            wordBreak: 'break-word',
            textAlign: 'left',
          }}
          placeholder="在此输入文字..."
        />

        {/* Character Count */}
        <div 
          className="absolute bottom-2 right-4 text-xs px-2 py-1 rounded-full bg-white/80 backdrop-blur-sm"
          style={{
            color: getSuitableContrastColor(backgroundColor.hex, textColor.hex),
          }}
        >
          {text.length}/{MAX_CHARS}
        </div>

        <button
          onClick={onOpenControls}
          className="absolute top-4 right-4 p-2 bg-white/90 rounded-full shadow-sm hover:bg-white/100 active:scale-95 transition-all"
        >
          <Settings className="w-5 h-5 text-stone-600" />
        </button>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={handleDownload}
          className="flex items-center justify-center p-3 bg-stone-800 text-white rounded-xl hover:bg-stone-900 active:scale-95 transition-all"
          title="下载图片"
        >
          <Download className="w-6 h-6" />
        </button>
        <button
          onClick={handleCopy}
          className="flex items-center justify-center p-3 bg-stone-100 text-stone-800 rounded-xl hover:bg-stone-200 active:scale-95 transition-all"
          title="复制到剪贴板"
        >
          <Copy className="w-6 h-6" />
        </button>
        <button
          onClick={() => setShowPreview(true)}
          className="flex items-center justify-center p-3 bg-stone-100 text-stone-800 rounded-xl hover:bg-stone-200 active:scale-95 transition-all"
          title="预览所有主题"
        >
          <Eye className="w-6 h-6" />
        </button>
      </div>

      {/* Preview Modal */}
      {showPreview && (
        <ThemePreview
          text={text}
          fontSize={fontSize}
          borderWidth={borderWidth}
          font={font}
          borderStyle={borderStyle}
          onClose={() => setShowPreview(false)}
        />
      )}
    </div>
  );
}