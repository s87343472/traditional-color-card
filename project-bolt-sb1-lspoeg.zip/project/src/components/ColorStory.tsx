import React from 'react';
import { X } from 'lucide-react';

interface ColorStoryProps {
  color: {
    name: string;
    story: string;
    hex: string;
  };
  onClose: () => void;
}

export function ColorStory({ color, onClose }: ColorStoryProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-xl w-[90vw] max-w-lg p-6" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-3">
            <div
              className="w-8 h-8 rounded-full"
              style={{ backgroundColor: color.hex }}
            />
            <h2 className="text-xl font-medium">{color.name}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-stone-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="prose prose-stone">
          <p className="text-stone-600 leading-relaxed">{color.story}</p>
        </div>
      </div>
    </div>
  );
}