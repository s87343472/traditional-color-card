import React from 'react';
import { X } from 'lucide-react';
import { ThemePicker } from './ThemePicker';
import { StyleControls } from './StyleControls';
import { themes } from '../data/themes';
import { fonts } from '../data/fonts';
import { borderStyles } from '../data/borderStyles';
import { useIsMobile } from '../hooks/useIsMobile';

interface ControlPanelProps {
  isOpen: boolean;
  onClose: () => void;
  themes: typeof themes;
  selectedTheme: typeof themes[0];
  onThemeSelect: (theme: typeof themes[0]) => void;
  fontSize: number;
  onFontSizeChange: (size: number) => void;
  borderWidth: number;
  onBorderWidthChange: (width: number) => void;
  selectedFont: typeof fonts[0];
  onFontChange: (font: typeof fonts[0]) => void;
  selectedBorderStyle: typeof borderStyles[0];
  onBorderStyleChange: (style: typeof borderStyles[0]) => void;
}

export function ControlPanel({
  isOpen,
  onClose,
  themes,
  selectedTheme,
  onThemeSelect,
  fontSize,
  onFontSizeChange,
  borderWidth,
  onBorderWidthChange,
  selectedFont,
  onFontChange,
  selectedBorderStyle,
  onBorderStyleChange,
}: ControlPanelProps) {
  const isMobile = useIsMobile();

  if (!isOpen) return null;

  // 移动端布局 - 左侧抽屉
  if (isMobile) {
    return (
      <>
        <div
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
          onClick={onClose}
        />
        <div className="fixed inset-y-0 left-0 w-[80vw] max-w-md bg-white shadow-lg z-50 transition-transform duration-300 ease-in-out">
          <div className="h-full flex flex-col">
            <div className="p-4 flex justify-between items-center border-b border-stone-100">
              <h2 className="text-lg font-medium">卡片设置</h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-stone-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <div className="p-4 space-y-6">
                <ThemePicker
                  themes={themes}
                  selectedTheme={selectedTheme}
                  onThemeSelect={onThemeSelect}
                />
                <StyleControls
                  fontSize={fontSize}
                  onFontSizeChange={onFontSizeChange}
                  borderWidth={borderWidth}
                  onBorderWidthChange={onBorderWidthChange}
                  selectedFont={selectedFont}
                  onFontChange={onFontChange}
                  selectedBorderStyle={selectedBorderStyle}
                  onBorderStyleChange={onBorderStyleChange}
                />
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  // 桌面端布局 - 两侧面板
  return (
    <div className="fixed inset-y-0 w-full pointer-events-none z-40 pt-20">
      <div className="container mx-auto h-[calc(100%-5rem)] flex gap-4 px-4">
        {/* 左侧主题面板 */}
        <div className="w-72 pointer-events-auto">
          <div className="bg-white h-full rounded-xl shadow-lg overflow-hidden">
            <div className="p-4 border-b border-stone-100 flex justify-between items-center">
              <h2 className="text-lg font-medium">主题选择</h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-stone-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 overflow-y-auto" style={{ height: 'calc(100% - 65px)' }}>
              <ThemePicker
                themes={themes}
                selectedTheme={selectedTheme}
                onThemeSelect={onThemeSelect}
              />
            </div>
          </div>
        </div>

        {/* 中间空白区域，用于显示编辑器 */}
        <div className="flex-1" />

        {/* 右侧样式面板 */}
        <div className="w-72 pointer-events-auto">
          <div className="bg-white h-full rounded-xl shadow-lg overflow-hidden">
            <div className="p-4 border-b border-stone-100">
              <h2 className="text-lg font-medium">样式设置</h2>
            </div>
            <div className="p-4 overflow-y-auto" style={{ height: 'calc(100% - 65px)' }}>
              <StyleControls
                fontSize={fontSize}
                onFontSizeChange={onFontSizeChange}
                borderWidth={borderWidth}
                onBorderWidthChange={onBorderWidthChange}
                selectedFont={selectedFont}
                onFontChange={onFontChange}
                selectedBorderStyle={selectedBorderStyle}
                onBorderStyleChange={onBorderStyleChange}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}