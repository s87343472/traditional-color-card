import React from 'react';
import { Type, Square, TextSelect, Layers } from 'lucide-react';
import { fonts } from '../data/fonts';
import { borderStyles } from '../data/borderStyles';

interface StyleControlsProps {
  fontSize: number;
  onFontSizeChange: (size: number) => void;
  borderWidth: number;
  onBorderWidthChange: (width: number) => void;
  selectedFont: typeof fonts[0];
  onFontChange: (font: typeof fonts[0]) => void;
  selectedBorderStyle: typeof borderStyles[0];
  onBorderStyleChange: (style: typeof borderStyles[0]) => void;
}

export function StyleControls({
  fontSize,
  onFontSizeChange,
  borderWidth,
  onBorderWidthChange,
  selectedFont,
  onFontChange,
  selectedBorderStyle,
  onBorderStyleChange,
}: StyleControlsProps) {
  return (
    <div className="space-y-6">
      {/* Font Family Selection */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <TextSelect className="w-4 h-4" />
          <h3 className="text-sm font-medium text-stone-800">字体样式</h3>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {fonts.map((font) => (
            <button
              key={font.name}
              onClick={() => onFontChange(font)}
              className={`p-2 rounded-lg text-left transition-all text-sm ${
                selectedFont.name === font.name
                  ? 'bg-stone-800 text-white'
                  : 'bg-stone-50 hover:bg-stone-100'
              }`}
              style={{ fontFamily: font.family }}
            >
              <div className="font-medium">{font.name}</div>
              <div className={`text-xs ${
                selectedFont.name === font.name ? 'text-stone-200' : 'text-stone-500'
              }`}>
                {font.description}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Border Style Selection */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Layers className="w-4 h-4" />
          <h3 className="text-sm font-medium text-stone-800">边框样式</h3>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {borderStyles.map((style) => (
            <button
              key={style.id}
              onClick={() => onBorderStyleChange(style)}
              className={`p-2 rounded-lg text-left transition-all text-sm ${
                selectedBorderStyle.id === style.id
                  ? 'bg-stone-800 text-white'
                  : 'bg-stone-50 hover:bg-stone-100'
              }`}
            >
              <div className="font-medium">{style.name}</div>
              <div className={`text-xs ${
                selectedBorderStyle.id === style.id ? 'text-stone-200' : 'text-stone-500'
              }`}>
                {style.description}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Font Size Control */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Type className="w-4 h-4" />
          <h3 className="text-sm font-medium text-stone-800">字体大小</h3>
        </div>
        <input
          type="range"
          min="24"
          max="48"
          value={fontSize}
          onChange={(e) => onFontSizeChange(Number(e.target.value))}
          className="w-full"
        />
        <div className="text-xs text-stone-600 mt-1 text-right">{fontSize}px</div>
      </div>

      {/* Border Width Control */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Square className="w-4 h-4" />
          <h3 className="text-sm font-medium text-stone-800">边框粗细</h3>
        </div>
        <input
          type="range"
          min="0"
          max="6"
          value={borderWidth}
          onChange={(e) => onBorderWidthChange(Number(e.target.value))}
          className="w-full"
        />
        <div className="text-xs text-stone-600 mt-1 text-right">{borderWidth}px</div>
      </div>
    </div>
  );
}