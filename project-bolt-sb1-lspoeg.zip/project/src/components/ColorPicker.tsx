import React, { useState } from 'react';
import { Color } from '../data/colors';
import { Search, Shuffle } from 'lucide-react';

interface ColorPickerProps {
  label: string;
  colors: Color[];
  selectedColor: Color;
  onColorSelect: (color: Color) => void;
}

export function ColorPicker({
  label,
  colors,
  selectedColor,
  onColorSelect,
}: ColorPickerProps) {
  const [hoveredColor, setHoveredColor] = useState<Color | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(0);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const colorsPerPage = 16;

  // 获取所有情感类别
  const emotions = ['all', ...new Set(colors.map(c => c.emotion).filter(Boolean))];
  const categories = [
    { id: 'all', name: '全部' },
    ...emotions.filter(e => e !== 'all').map(emotion => ({
      id: emotion,
      name: emotion,
    })),
  ];

  // 随机选择颜色
  const handleRandomColor = () => {
    const randomIndex = Math.floor(Math.random() * colors.length);
    onColorSelect(colors[randomIndex]);
  };

  // 过滤颜色
  const filteredColors = colors.filter(color => {
    const matchesSearch = 
      color.name.includes(searchTerm) || 
      color.pinyin.toLowerCase().includes(searchTerm.toLowerCase()) ||
      color.hex.toLowerCase().includes(searchTerm.toLowerCase()) ||
      color.emotion?.includes(searchTerm);
    
    const matchesCategory = 
      activeCategory === 'all' || 
      color.emotion === activeCategory;

    return matchesSearch && matchesCategory;
  });

  const totalPages = Math.ceil(filteredColors.length / colorsPerPage);
  const displayedColors = filteredColors.slice(
    currentPage * colorsPerPage,
    (currentPage + 1) * colorsPerPage
  );

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-lg font-medium text-stone-800">{label}</h3>
        <button
          onClick={handleRandomColor}
          className="flex items-center gap-1 text-sm text-stone-600 hover:text-stone-900"
        >
          <Shuffle className="w-4 h-4" />
          随机
        </button>
      </div>
      
      {/* Search Bar */}
      <div className="relative mb-4">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(0);
          }}
          placeholder="搜索颜色名称、拼音或情感..."
          className="w-full pl-10 pr-4 py-2 bg-white rounded-lg border border-stone-200 focus:outline-none focus:ring-2 focus:ring-stone-500"
        />
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-2 mb-4">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => {
              setActiveCategory(category.id);
              setCurrentPage(0);
            }}
            className={`px-3 py-1 rounded-full text-sm ${
              activeCategory === category.id
                ? 'bg-stone-800 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>

      {/* Color Info Display */}
      <div className="h-16 mb-4 p-4 bg-white rounded-lg shadow-sm">
        {(hoveredColor || selectedColor) && (
          <div className="text-center">
            <div className="text-lg font-medium">
              {hoveredColor?.name || selectedColor.name}
              {(hoveredColor?.emotion || selectedColor.emotion) && 
                <span className="ml-2 text-sm text-stone-500">
                  ({hoveredColor?.emotion || selectedColor.emotion})
                </span>
              }
            </div>
            <div className="text-sm text-stone-500">
              {hoveredColor?.pinyin || selectedColor.pinyin} · {hoveredColor?.hex || selectedColor.hex}
            </div>
          </div>
        )}
      </div>

      {/* Color Grid */}
      <div className="grid grid-cols-4 gap-2">
        {displayedColors.map((color) => (
          <button
            key={color.name + color.hex}
            onClick={() => onColorSelect(color)}
            onMouseEnter={() => setHoveredColor(color)}
            onMouseLeave={() => setHoveredColor(null)}
            className={`group relative w-full aspect-square rounded-lg transition-all duration-200 ${
              selectedColor.hex === color.hex
                ? 'ring-2 ring-offset-2 ring-stone-800'
                : 'hover:scale-105'
            }`}
            style={{ backgroundColor: color.hex }}
            title={`${color.name} - ${color.emotion || ''}`}
          >
            {color.emotion && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-stone-800" />
            )}
            <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg" />
          </button>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-4">
          {Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentPage(index)}
              className={`w-8 h-8 rounded-full ${
                currentPage === index
                  ? 'bg-stone-800 text-white'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {index + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}