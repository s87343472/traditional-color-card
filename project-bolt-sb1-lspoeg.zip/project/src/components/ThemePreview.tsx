import React, { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { themes } from '../data/themes';
import { getSuitableContrastColor } from '../utils/colors';
import { fonts } from '../data/fonts';
import { borderStyles } from '../data/borderStyles';

interface ThemePreviewProps {
  text: string;
  fontSize: number;
  borderWidth: number;
  font: typeof fonts[0];
  borderStyle: typeof borderStyles[0];
  onClose: () => void;
}

export function ThemePreview({
  text,
  fontSize,
  borderWidth,
  font,
  borderStyle,
  onClose,
}: ThemePreviewProps) {
  const [currentPage, setCurrentPage] = useState(0);
  const themesPerPage = 6;
  const totalPages = Math.ceil(themes.length / themesPerPage);

  const displayedThemes = themes.slice(
    currentPage * themesPerPage,
    (currentPage + 1) * themesPerPage
  );

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl w-[90vw] h-[90vh] flex flex-col">
        <div className="p-4 border-b border-stone-200 flex justify-between items-center">
          <h2 className="text-xl font-medium">主题预览</h2>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(0, p - 1))}
                disabled={currentPage === 0}
                className="p-2 hover:bg-stone-100 rounded-lg transition-colors disabled:opacity-50"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <span className="text-sm text-stone-600">
                {currentPage + 1} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages - 1, p + 1))}
                disabled={currentPage === totalPages - 1}
                className="p-2 hover:bg-stone-100 rounded-lg transition-colors disabled:opacity-50"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-stone-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
        
        <div className="flex-1 overflow-auto p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayedThemes.map((theme) => (
              <div key={theme.id} className="space-y-2">
                <div
                  className="aspect-[4/5] rounded-lg shadow-lg transition-all duration-300 relative"
                  style={{
                    backgroundColor: theme.backgroundColor.hex,
                    border: `${borderWidth}px ${borderStyle.value} ${theme.borderColor.hex}`,
                  }}
                >
                  <div className="absolute inset-0 flex items-center justify-center p-8">
                    <div
                      className="w-4/5 h-[90%]"
                      style={{
                        color: getSuitableContrastColor(
                          theme.backgroundColor.hex,
                          theme.textColor.hex
                        ),
                        fontSize: `${fontSize * 0.75}px`,
                        fontFamily: font.family,
                        lineHeight: '2',
                        whiteSpace: 'pre-wrap',
                        overflowWrap: 'break-word',
                        wordBreak: 'break-word',
                        textAlign: 'left',
                      }}
                    >
                      {text}
                    </div>
                  </div>
                </div>
                <div className="text-center">
                  <div className="font-medium">{theme.name}</div>
                  <div className="text-sm text-stone-500">{theme.emotion}</div>
                  <div className="text-xs text-stone-400 mt-1">{theme.description}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}