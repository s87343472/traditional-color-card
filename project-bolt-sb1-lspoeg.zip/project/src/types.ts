export interface Color {
  name: string;
  pinyin: string;
  hex: string;
  emotion?: string;
  story?: string;
}