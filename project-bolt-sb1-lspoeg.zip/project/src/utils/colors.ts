// 计算颜色的相对亮度
function getLuminance(r: number, g: number, b: number): number {
  const [rs, gs, bs] = [r, g, b].map(c => {
    c = c / 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

// 将十六进制颜色转换为RGB
function hexToRgb(hex: string): [number, number, number] {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) {
    throw new Error('Invalid hex color');
  }
  return [
    parseInt(result[1], 16),
    parseInt(result[2], 16),
    parseInt(result[3], 16),
  ];
}

// 判断颜色是否为暗色
export function isDarkColor(hex: string): boolean {
  const rgb = hexToRgb(hex);
  const luminance = getLuminance(...rgb);
  return luminance < 0.5;
}

// 获取合适的对比色
export function getSuitableContrastColor(bgHex: string, preferredTextHex: string): string {
  const bgIsDark = isDarkColor(bgHex);
  const textIsDark = isDarkColor(preferredTextHex);
  
  // 如果背景和文字的明暗度相似，返回相反的颜色
  if (bgIsDark === textIsDark) {
    return bgIsDark ? '#FFFFFF' : '#000000';
  }
  
  return preferredTextHex;
}

// 获取推荐的背景色
export function getSuitableBackgroundColor(textHex: string, currentBgHex: string, colors: any[]): string {
  const textIsDark = isDarkColor(textHex);
  const currentBgIsDark = isDarkColor(currentBgHex);
  
  // 如果文字和背景的明暗度相似，寻找合适的背景色
  if (textIsDark === currentBgIsDark) {
    // 从颜色列表中找到第一个合适的颜色
    const suitableColor = colors.find(color => 
      isDarkColor(color.hex) !== textIsDark
    );
    
    return suitableColor ? suitableColor.hex : (textIsDark ? '#FFFFFF' : '#000000');
  }
  
  return currentBgHex;
}